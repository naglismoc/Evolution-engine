import java.util.*;

public class Main {

    //Map<Integer, Object> myMap = new HashMap<>();
    //myMap.put(1,new Pimpackiukas().numeris);
//        System.out.println(  myMap.get(1));

    public static void main(String[] args) {
        ArrayList<Pimpackiukas> kiekGyvu = new ArrayList<>();
        Pimpackiukas pimp = new Pimpackiukas(0.5, 0.6,0.01, "1", true);
        kiekGyvu.add(pimp);
        // Pimpackiukas pimp1 = new Pimpackiukas(0.6,0.2,"2",true);
        kiekGyvu.add(new Pimpackiukas(0.6, 0.65,0.02, "2", true));
        //Pimpackiukas pimp2 = new Pimpackiukas(0.5,0.3,"3",true);
        kiekGyvu.add(new Pimpackiukas(0.7, 0.7,0.03, "3", true));
//        kiekGyvu.get(2).arGyvas = false;
//        System.out.println(kiekGyvu.get(2).arGyvas);
        ArrayList<Integer> dnrFabrikas = new ArrayList<>();
        ///////////////////////konsole///////////////////////////////////////
        int kiekDienu = 100;
        double prastejantisKlimatas =15;


        pimp.setKiekDienu(kiekDienu);//kiek dienu nunesa i kita klase


        int[] gyvuNotRemove = new int[kiekDienu * kiekDienu];
        int gyvuCount = 0;
        int gyvuNotCount=0;
        int kiekNemire=0;



        for (int i = 0; i < kiekDienu; i++) {
    int nenumirusieji = (kiekGyvu.size() - gyvuNotCount);
            System.out.println("tikrinu atveikia 'visi ismiro'. "+kiekGyvu.size()+" - "+gyvuNotCount);
            if (nenumirusieji==0){
                System.out.println("visi ismiro");
                break;
            }

//
            //pasisveikinimas
            pimp.pradzia(i, kiekGyvu.size(),nenumirusieji);
            Pimpackiukas.arYraGyvu(kiekGyvu.size());

            for (int h = 0; h < kiekGyvu.size(); h++) {

                if (kiekGyvu.get(h).arGyvas == false) {


                    continue;
                }
                double rnd = Math.random() *100;


                //System.out.println("random = "+random);
                double istverme = kiekGyvu.get(h).istverme ;
               // System.out.println(kiekGyvu.get(h).numeris + "-ojo pimpackiuko istverme - " + istverme);
                if (rnd <= ((istverme*100)-prastejantisKlimatas*i)) {

                    gyvuCount++;

//                    Object laikinas = kiekGyvu.get(0);
//                    System.out.println(laikinas);
                    System.out.println(kiekGyvu.get(h).numeris + "-ojo pimpackiuko istverme - " + istverme +". Jis isgyveno ir pasidaugino, gime " + (kiekGyvu.size() + gyvuCount) + "-asis pimpackiukas");

                    dnrFabrikas.add(h);
                } else {
                    gyvuNotCount++;
                    System.out.println("deje " + (h + 1) + "-tasis pimpackiukas neisgyveno, gyvuju liko " + (kiekGyvu.size() - gyvuNotCount)+". GyvuNotCount yra " +gyvuNotCount+", ir is viso buvo "+kiekGyvu.size());
                    kiekGyvu.get(h).arGyvas = false;

                    // System.out.println(kiekGyvu.get(h).arGyvas);

                    //   gyvuNotRemove[gyvuCount] = i;

                    //System.out.println("dienos pabaigoje gyvuju yra " + kiekGyvu.size());
                }
            }

            for (int d = 0; d < dnrFabrikas.size(); d++) {
                double rnd = Math.random()*100 ;

                int random = (int) rnd/100;

             //   double tevoIstverme = kiekGyvu.get(dnrFabrikas.get(d)).istverme ;

                if (kiekGyvu.get(d).istvermesEvoliucijosTikimybe > random) {

                    double vaikoIstverme = (1+kiekGyvu.get(d).istvermesEvoliucijosKoefecientas) * kiekGyvu.get(d).istverme;
                    String vardas = kiekGyvu.get(dnrFabrikas.get(d)).numeris;
                    vardas= vardas+"/"+(d+1);
                    kiekGyvu.add(new Pimpackiukas(vaikoIstverme, kiekGyvu.get(dnrFabrikas.get(d)).istvermesEvoliucijosTikimybe,kiekGyvu.get(dnrFabrikas.get(d)).istvermesEvoliucijosKoefecientas, vardas, true));
                }
                else{
                    String vardas = kiekGyvu.get(dnrFabrikas.get(d)).numeris;
                    vardas= vardas+"/"+(d+1);
                    double vaikoIstverme = (1+kiekGyvu.get(d).istvermesEvoliucijosKoefecientas) * kiekGyvu.get(d).istverme;
                    kiekGyvu.add(new Pimpackiukas(vaikoIstverme, kiekGyvu.get(dnrFabrikas.get(d)).istvermesEvoliucijosTikimybe,kiekGyvu.get(dnrFabrikas.get(d)).istvermesEvoliucijosKoefecientas, vardas, true));
                }
            }
//        for (int g = 0; g < gyvuCount; g++) {
//            kiekGyvu.add(new Pimpackiukas());
//        }
//
//        for (int f = 0; f < gyvuNotCount; f++) {
//            if (kiekGyvu.size() > 0) {
//                kiekGyvu.remove(f);
//            }
//        }
            gyvuCount = 0;
//        gyvuNotCount = 0;



        }
    }
}
