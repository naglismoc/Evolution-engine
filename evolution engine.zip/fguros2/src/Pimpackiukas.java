import java.util.ArrayList;
//pimpackiuko parametrai
public class Pimpackiukas {
     double istverme;
     double istvermesEvoliucijosTikimybe;
     double istvermesEvoliucijosKoefecientas;
     String numeris;
     boolean arGyvas;


    ///////////////formuliu kintamieji//////////////////
   public int kiekDienu =0;



    //konstruktorius
    public Pimpackiukas() {

    }

    //konstruktorius
    public Pimpackiukas(String numeris) {
        this.numeris = numeris;
    }
    //konstruktorius
    public Pimpackiukas(double istverme, double istvermesEvoliucijosTikimybe,     double istvermesEvoliucijosKoefecientas,String numeris,boolean arGyvas) {
        this.istverme = istverme;
        this.istvermesEvoliucijosTikimybe = istvermesEvoliucijosTikimybe;
        this.istvermesEvoliucijosKoefecientas = istvermesEvoliucijosKoefecientas;
        this.numeris = numeris;
        this.arGyvas = arGyvas;
    }




    public int getKiekDienu() {
        return kiekDienu;
    }

    public void setKiekDienu(int kiekDienu) {
        this.kiekDienu = kiekDienu;
    }



        //pasisveikinimas
    public   void pradzia(int i,int gyvuKiekis,int kiekNemire) {
        System.out.println();
        System.out.println("atejo " + (i + 1) + "-oji diena is "+kiekDienu);



        System.out.println("dienos pradzioje gyvuju yra  " + kiekNemire);
        System.out.println("kadangi yra " + kiekNemire + " gyvu pimpackiuku, ziuriu kurie sia diena isgyvena");

    }
    //ar ir kas jei nera gyvu pimpackiuku
    public  static void arYraGyvu(int gyvuKiekis){
        if (gyvuKiekis == 0) {
            System.out.println("kadangi nera gyvuju baigiam cikla");
            return;
        }
    }


}
